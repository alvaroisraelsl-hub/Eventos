/* ====================================================================
   ALCANCE EVENTOS — Gestão Script
   - Login (demo: qualquer credencial)
   - Navegação entre views
   - Dashboard com dados reais (puxa do localStorage + mocks)
   - Tabela de eventos, participantes, checkin, financeiro, relatórios
   ==================================================================== */

/* ---------------------------------------------------
   MOCK DATA — Eventos com vendas pré-existentes
--------------------------------------------------- */
const EVENTOS_MGMT = [
  { id: 'conf-fe-2025', name: 'Conferência da Fé 2025', date: '22 Jun · Domingo', local: 'Templo Central', capacity: 500, sold: 347, revenue: 31580, status: 'Ativo' },
  { id: 'retiro-verao', name: 'Retiro de Verão', date: '12-14 Jul · FDS', local: 'Sítio Renova', capacity: 200, sold: 188, revenue: 38260, status: 'Quase esgotado' },
  { id: 'noite-louvor', name: 'Noite de Louvor', date: '5 Ago · Terça', local: 'Auditório Central', capacity: 800, sold: 312, revenue: 4560, status: 'Ativo' },
  { id: 'noite-nacoes', name: 'Noite das Nações', date: '14 Set · Sábado', local: 'Sede Central', capacity: 600, sold: 142, revenue: 8420, status: 'Ativo' },
  { id: 'casais-conexao', name: 'Casais em Conexão', date: '11 Out · Sábado', local: 'Salão Nobre', capacity: 120, sold: 58, revenue: 15240, status: 'Ativo' },
  { id: 'celebracao-natal', name: 'Celebração de Natal', date: '20 Dez · Sábado', local: 'Templo Central', capacity: 1000, sold: 0, revenue: 0, status: 'Em breve' }
];

// Participantes mock (que se mistura com reservas reais do localStorage)
const PARTICIPANTES_MOCK = [
  { id: 'CF-1234-ABCD', portador: 'Maria Oliveira', email: 'maria@email.com', eventName: 'Conferência da Fé 2025', tipo: 'Área VIP', total: 149, status: 'pago', timestamp: Date.now() - 86400000 * 2, validated: true },
  { id: 'CF-5678-EFGH', portador: 'João Silva', email: 'joao@email.com', eventName: 'Conferência da Fé 2025', tipo: 'Acesso Geral', total: 79, status: 'pago', timestamp: Date.now() - 86400000 * 3, validated: false },
  { id: 'RV-9012-IJKL', portador: 'Ana Souza', email: 'ana@email.com', eventName: 'Retiro de Verão', tipo: 'Individual', total: 189, status: 'pago', timestamp: Date.now() - 86400000 * 5, validated: false },
  { id: 'NL-3456-MNOP', portador: 'Carlos Henrique', email: 'carlos@email.com', eventName: 'Noite de Louvor', tipo: 'Apoiador', total: 30, status: 'pago', timestamp: Date.now() - 86400000 * 1, validated: true },
  { id: 'RV-7890-QRST', portador: 'Fernanda Lima', email: 'fernanda@email.com', eventName: 'Retiro de Verão', tipo: 'Casal', total: 340, status: 'pago', timestamp: Date.now() - 86400000 * 7, validated: false },
  { id: 'CC-1357-UVWX', portador: 'Roberto e Sandra', email: 'roberto@email.com', eventName: 'Casais em Conexão', tipo: 'Casal Premium', total: 360, status: 'pago', timestamp: Date.now() - 86400000 * 4, validated: false },
  { id: 'CF-2468-YZAB', portador: 'Patricia Mendes', email: 'patricia@email.com', eventName: 'Conferência da Fé 2025', tipo: 'Família (2+2)', total: 249, status: 'pago', timestamp: Date.now() - 86400000 * 6, validated: true },
  { id: 'NN-9753-CDEF', portador: 'Lucas Pereira', email: 'lucas@email.com', eventName: 'Noite das Nações', tipo: 'Jantar Internacional', total: 89, status: 'pago', timestamp: Date.now() - 86400000 * 8, validated: false }
];

/* ---------------------------------------------------
   LOGIN
--------------------------------------------------- */
function checkAuth() {
  return sessionStorage.getItem('alcance_auth') === '1';
}

function login() {
  const email = document.getElementById('lg-email').value.trim();
  const pass = document.getElementById('lg-pass').value.trim();
  if (!email || !pass) {
    showToast('Preencha e-mail e senha');
    return;
  }
  sessionStorage.setItem('alcance_auth', '1');
  showDashboard();
  showToast('Bem-vinda, Pastora Ana');
}

function logout() {
  sessionStorage.removeItem('alcance_auth');
  document.getElementById('dashboard').classList.add('hidden');
  document.getElementById('login-screen').classList.remove('hidden');
}

function showDashboard() {
  document.getElementById('login-screen').classList.add('hidden');
  document.getElementById('dashboard').classList.remove('hidden');
  initDashboard();
}

/* ---------------------------------------------------
   PUXAR DADOS REAIS + MOCK
--------------------------------------------------- */
function getAllReservas() {
  const real = JSON.parse(localStorage.getItem('alcance_reservas') || '[]');
  return [...PARTICIPANTES_MOCK, ...real];
}

function totalReceita() {
  return EVENTOS_MGMT.reduce((sum, e) => sum + e.revenue, 0)
       + getAllReservas().filter(r => !PARTICIPANTES_MOCK.find(p => p.id === r.id))
                        .reduce((s, r) => s + (r.total || 0), 0);
}

function totalVendidos() {
  return EVENTOS_MGMT.reduce((s, e) => s + e.sold, 0)
       + (getAllReservas().length - PARTICIPANTES_MOCK.length);
}

function totalCheckin() {
  return getAllReservas().filter(r => r.validated).length + 612; // base mock
}

/* ---------------------------------------------------
   VIEWS NAVIGATION
--------------------------------------------------- */
function switchView(viewName) {
  document.querySelectorAll('.sb-item').forEach(b => {
    b.classList.toggle('active', b.dataset.view === viewName);
  });
  document.querySelectorAll('.view').forEach(v => {
    v.classList.toggle('active', v.id === 'view-' + viewName);
  });

  const titles = {
    overview: { t: 'Visão Geral', s: 'Bem-vinda de volta, Pastora Ana' },
    eventos: { t: 'Eventos', s: 'Gerencie todos os eventos' },
    participantes: { t: 'Participantes', s: 'Lista completa de inscritos' },
    checkin: { t: 'Check-in', s: 'Validação na entrada' },
    financeiro: { t: 'Financeiro', s: 'Receitas e repasses' },
    relatorios: { t: 'Relatórios', s: 'Análises e exportações' },
    config: { t: 'Configurações', s: 'Ajustes da plataforma' }
  };
  const cfg = titles[viewName];
  if (cfg) {
    document.getElementById('topbar-title').textContent = cfg.t;
    document.getElementById('topbar-sub').textContent = cfg.s;
  }

  // Re-render se necessário
  if (viewName === 'overview') renderOverview();
  if (viewName === 'eventos') renderEventosTable();
  if (viewName === 'participantes') renderParticipantes();
  if (viewName === 'financeiro') renderFinanceiro();
}

/* ---------------------------------------------------
   VIEW: OVERVIEW
--------------------------------------------------- */
function renderOverview() {
  const receita = totalReceita();
  const vendidos = totalVendidos();
  const checkin = totalCheckin();
  const eventos = EVENTOS_MGMT.length;

  document.getElementById('m-receita').textContent = receita.toLocaleString('pt-BR');
  document.getElementById('m-vendidos').textContent = vendidos.toLocaleString('pt-BR');
  document.getElementById('m-checkin').textContent = checkin.toLocaleString('pt-BR');
  document.getElementById('m-eventos').textContent = eventos;

  // Vendas por evento
  const list = document.getElementById('event-progress');
  list.innerHTML = '';
  EVENTOS_MGMT.slice(0, 5).forEach(ev => {
    const pct = ev.capacity > 0 ? (ev.sold / ev.capacity) * 100 : 0;
    const row = document.createElement('div');
    row.className = 'event-progress-item';
    row.innerHTML = `
      <div class="epi-left">
        <div class="epi-name">${ev.name}</div>
        <div class="epi-date">${ev.date} · ${ev.capacity} vagas</div>
      </div>
      <div class="epi-right">
        <div class="epi-count">${ev.sold} <span>/ ${ev.capacity}</span></div>
        <div class="epi-bar-wrap"><div class="epi-bar" style="width:${pct}%"></div></div>
      </div>
    `;
    list.appendChild(row);
  });

  // Atividade recente
  const feed = document.getElementById('activity-feed');
  feed.innerHTML = '';
  const activities = [
    { icon: 'plus', text: '<strong>Maria Oliveira</strong> reservou Conferência da Fé · VIP', time: '2 min atrás' },
    { icon: 'check', text: '<strong>Carlos Henrique</strong> fez check-in na Noite de Louvor', time: '14 min atrás' },
    { icon: 'plus', text: '<strong>Ana Souza</strong> reservou Retiro de Verão · Individual', time: '1h atrás' },
    { icon: 'dollar', text: '<strong>Pagamento confirmado</strong> · R$ 340 · Casais em Conexão', time: '2h atrás' },
    { icon: 'plus', text: '<strong>Patricia Mendes</strong> reservou Conferência da Fé · Família', time: '3h atrás' }
  ];
  const icons = {
    plus: '<polyline points="20,6 9,17 4,12"/>',
    check: '<polyline points="20,6 9,17 4,12"/>',
    dollar: '<line x1="12" y1="1" x2="12" y2="23"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/>'
  };
  activities.forEach(a => {
    const it = document.createElement('div');
    it.className = 'activity-item';
    it.innerHTML = `
      <div class="act-icon"><svg viewBox="0 0 24 24">${icons[a.icon]}</svg></div>
      <div class="act-content">
        <div class="act-title">${a.text}</div>
        <div class="act-time">${a.time}</div>
      </div>
    `;
    feed.appendChild(it);
  });

  // Chart de vendas
  renderSalesChart();
}

function renderSalesChart() {
  const svg = document.getElementById('sales-chart');
  if (!svg) return;
  svg.innerHTML = '';

  // Dados simulados: 30 dias
  const days = 30;
  const data = [];
  let v = 800;
  for (let i = 0; i < days; i++) {
    v += (Math.random() - 0.4) * 400;
    v = Math.max(200, Math.min(3500, v));
    data.push(v);
  }

  const W = 800, H = 240;
  const padding = { top: 20, right: 20, bottom: 30, left: 50 };
  const innerW = W - padding.left - padding.right;
  const innerH = H - padding.top - padding.bottom;

  const max = Math.max(...data) * 1.1;
  const xStep = innerW / (data.length - 1);

  // Grid
  const gridG = `<g stroke="rgba(201,168,76,0.08)" stroke-width="0.5">`;
  let gridLines = '';
  for (let i = 0; i <= 4; i++) {
    const y = padding.top + (innerH * i) / 4;
    gridLines += `<line x1="${padding.left}" x2="${W - padding.right}" y1="${y}" y2="${y}" />`;
    const val = Math.round((max * (4 - i)) / 4);
    gridLines += `<text x="${padding.left - 8}" y="${y + 4}" text-anchor="end" fill="rgba(122,110,92,0.7)" font-size="10" font-family="Outfit">R$ ${val.toLocaleString('pt-BR')}</text>`;
  }
  gridLines += `</g>`;

  // Área (gradiente)
  let areaPath = `M ${padding.left} ${padding.top + innerH}`;
  data.forEach((d, i) => {
    const x = padding.left + i * xStep;
    const y = padding.top + innerH - (d / max) * innerH;
    areaPath += ` L ${x} ${y}`;
  });
  areaPath += ` L ${W - padding.right} ${padding.top + innerH} Z`;

  // Linha
  let linePath = '';
  data.forEach((d, i) => {
    const x = padding.left + i * xStep;
    const y = padding.top + innerH - (d / max) * innerH;
    linePath += (i === 0 ? 'M' : 'L') + ` ${x} ${y} `;
  });

  // Labels x
  let xLabels = '';
  const labelDays = [0, 7, 14, 21, 29];
  labelDays.forEach(i => {
    const x = padding.left + i * xStep;
    xLabels += `<text x="${x}" y="${H - 10}" text-anchor="middle" fill="rgba(122,110,92,0.7)" font-size="10" font-family="Outfit">${days - i}d</text>`;
  });

  svg.innerHTML = `
    <defs>
      <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0%" stop-color="#C9A84C" stop-opacity="0.4"/>
        <stop offset="100%" stop-color="#C9A84C" stop-opacity="0"/>
      </linearGradient>
    </defs>
    ${gridG.replace('<g', '<g>')}${gridLines}
    <path d="${areaPath}" fill="url(#areaGrad)" />
    <path d="${linePath}" fill="none" stroke="#C9A84C" stroke-width="1.5" stroke-linejoin="round" stroke-linecap="round" />
    ${data.map((d, i) => {
      if (i % 5 !== 0) return '';
      const x = padding.left + i * xStep;
      const y = padding.top + innerH - (d / max) * innerH;
      return `<circle cx="${x}" cy="${y}" r="3" fill="#C9A84C" stroke="#0E0B07" stroke-width="2" />`;
    }).join('')}
    ${xLabels}
  `;
}

/* ---------------------------------------------------
   VIEW: EVENTOS
--------------------------------------------------- */
function renderEventosTable() {
  const body = document.getElementById('events-table-body');
  body.innerHTML = '';
  EVENTOS_MGMT.forEach(ev => {
    const row = document.createElement('div');
    row.className = 'events-table-row';

    const statusClass = ev.status === 'Quase esgotado' ? 'warn'
                       : ev.status === 'Em breve' ? '' : 'green';

    row.innerHTML = `
      <div class="evt-cell-name">
        <div class="evt-cell-thumb">✦</div>
        <div>
          <div class="evt-name">${ev.name}</div>
          <div class="evt-local">${ev.local}</div>
        </div>
      </div>
      <div style="color:var(--cream-2);font-size:13px;">${ev.date}</div>
      <div style="color:var(--cream);font-size:13.5px;">${ev.sold}<span style="color:var(--muted);font-size:11.5px;"> / ${ev.capacity}</span></div>
      <div class="evt-cell-revenue">R$ ${ev.revenue.toLocaleString('pt-BR')}</div>
      <div><span class="status-tag ${statusClass}">${ev.status}</span></div>
      <div class="row-actions">
        <button class="row-action-btn" aria-label="Editar"><svg viewBox="0 0 24 24"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg></button>
        <button class="row-action-btn" aria-label="Ver mais"><svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="1"/><circle cx="12" cy="5" r="1"/><circle cx="12" cy="19" r="1"/></svg></button>
      </div>
    `;
    body.appendChild(row);
  });
}

/* ---------------------------------------------------
   VIEW: PARTICIPANTES
--------------------------------------------------- */
function renderParticipantes(filter = '') {
  const all = getAllReservas().sort((a, b) => b.timestamp - a.timestamp);
  const filtered = filter ? all.filter(p =>
    (p.portador || '').toLowerCase().includes(filter.toLowerCase()) ||
    (p.email || '').toLowerCase().includes(filter.toLowerCase()) ||
    (p.eventName || '').toLowerCase().includes(filter.toLowerCase())
  ) : all;

  const body = document.getElementById('part-table-body');
  const empty = document.getElementById('part-empty');

  if (filtered.length === 0) {
    body.innerHTML = '';
    empty.classList.remove('hidden');
    return;
  }
  empty.classList.add('hidden');

  body.innerHTML = '';
  filtered.forEach(p => {
    const initials = (p.portador || '').split(' ').map(s => s[0]).join('').slice(0, 2).toUpperCase();
    const date = new Date(p.timestamp);
    const dateStr = date.toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });

    const row = document.createElement('div');
    row.className = 'part-table-row';
    row.innerHTML = `
      <div class="part-cell-user">
        <div class="part-avatar">${initials || '?'}</div>
        <div>
          <div class="part-name">${p.portador}</div>
          <div class="part-email">${p.email || '—'}</div>
        </div>
      </div>
      <div style="color:var(--cream-2);font-size:13px;">${p.eventName}</div>
      <div style="color:var(--muted);font-size:12.5px;">${p.tipo}</div>
      <div style="color:var(--gold);font-family:'Cormorant Garamond',serif;font-size:16px;">
        ${p.total === 0 ? 'Grátis' : 'R$ ' + p.total}
      </div>
      <div><span class="status-tag ${p.validated ? 'green' : 'gold'}">${p.validated ? 'Compareceu' : 'Pago'}</span></div>
      <div style="color:var(--muted);font-size:11.5px;letter-spacing:0.05em;">${dateStr}</div>
    `;
    body.appendChild(row);
  });
}

/* ---------------------------------------------------
   VIEW: CHECK-IN
--------------------------------------------------- */
let checkinLog = [];
let validCount = 0;
let invalidCount = 0;

function renderCheckinLog() {
  const log = document.getElementById('checkin-log');
  log.innerHTML = '';
  if (checkinLog.length === 0) {
    log.innerHTML = `<div style="text-align:center;padding:40px 20px;color:var(--muted);font-size:13px;">Aguardando validações...</div>`;
    return;
  }
  checkinLog.slice().reverse().forEach(entry => {
    const time = new Date(entry.timestamp).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
    const it = document.createElement('div');
    it.className = 'checkin-log-item';
    it.innerHTML = `
      <div class="cl-status ${entry.valid ? 'valid' : 'invalid'}"></div>
      <div class="cl-info">
        <div class="cl-name">${entry.valid ? entry.name : 'Código inválido'}</div>
        <div class="cl-event">${entry.valid ? entry.event : entry.code}</div>
      </div>
      <div class="cl-time">${time}</div>
    `;
    log.appendChild(it);
  });
  document.getElementById('ci-valid').textContent = validCount;
  document.getElementById('ci-invalid').textContent = invalidCount;
}

function validateManual() {
  const codeEl = document.getElementById('manual-code');
  const code = codeEl.value.trim().toUpperCase();
  if (!code) {
    showToast('Insira um código');
    return;
  }
  // Procura nas reservas
  const all = getAllReservas();
  const found = all.find(p => (p.id || '').toUpperCase() === code);

  if (found) {
    checkinLog.push({
      valid: true,
      name: found.portador,
      event: `${found.eventName} · ${found.tipo}`,
      code,
      timestamp: Date.now()
    });
    validCount++;
    showToast('✓ Entrada validada: ' + found.portador);
  } else {
    checkinLog.push({
      valid: false,
      code,
      timestamp: Date.now()
    });
    invalidCount++;
    showToast('✗ Código não encontrado');
  }
  codeEl.value = '';
  renderCheckinLog();
}

/* Simulador automático de check-in para demo */
function startCheckinDemo() {
  // adiciona algumas entradas iniciais para parecer "vivo"
  const samples = [
    { valid: true, name: 'João da Silva', event: 'Conferência da Fé · VIP' },
    { valid: true, name: 'Maria Fernanda', event: 'Conferência da Fé · Geral' },
    { valid: false, code: 'XYZ-INV-9999' },
    { valid: true, name: 'Carlos Henrique', event: 'Conferência da Fé · Família' },
    { valid: true, name: 'Patricia Mendes', event: 'Noite de Louvor · Apoiador' }
  ];
  samples.forEach((s, i) => {
    setTimeout(() => {
      checkinLog.push({ ...s, timestamp: Date.now() - (samples.length - i) * 60000 });
      if (s.valid) validCount++; else invalidCount++;
      renderCheckinLog();
    }, i * 80);
  });
}

/* ---------------------------------------------------
   VIEW: FINANCEIRO
--------------------------------------------------- */
function renderFinanceiro() {
  const bruta = totalReceita();
  const taxa = Math.round(bruta * 0.05);
  const liquida = bruta - taxa;

  document.getElementById('f-bruta').textContent = bruta.toLocaleString('pt-BR');
  document.getElementById('f-taxa').textContent = taxa.toLocaleString('pt-BR');
  document.getElementById('f-liquida').textContent = liquida.toLocaleString('pt-BR');

  // Breakdown de pagamento (mock: 68% Pix, 32% Cartão)
  document.getElementById('pb-pix').style.width = '68%';
  document.getElementById('pv-pix').textContent = '68%';
  document.getElementById('pb-cartao').style.width = '32%';
  document.getElementById('pv-cartao').textContent = '32%';

  // Últimas transações
  const trList = document.getElementById('transaction-list');
  trList.innerHTML = '';
  const transactions = getAllReservas()
    .filter(p => p.total > 0)
    .sort((a, b) => b.timestamp - a.timestamp)
    .slice(0, 8);

  transactions.forEach(t => {
    const initials = (t.portador || '').split(' ').map(s => s[0]).join('').slice(0, 2).toUpperCase();
    const date = new Date(t.timestamp).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
    const row = document.createElement('div');
    row.className = 'transaction-row';
    row.innerHTML = `
      <div class="tr-left">
        <div class="tr-icon">${initials}</div>
        <div>
          <div class="tr-info-name">${t.portador}</div>
          <div class="tr-info-meta">${t.eventName} · ${date}</div>
        </div>
      </div>
      <div class="tr-amount">R$ ${t.total.toLocaleString('pt-BR')}</div>
    `;
    trList.appendChild(row);
  });

  if (transactions.length === 0) {
    trList.innerHTML = '<div style="text-align:center;padding:30px;color:var(--muted);font-size:13px;">Nenhuma transação ainda</div>';
  }
}

/* ---------------------------------------------------
   TOAST (reaproveitado do script.js)
--------------------------------------------------- */
function showToast(msg) {
  const t = document.getElementById('toast');
  if (!t) return;
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2400);
}

/* ---------------------------------------------------
   INIT
--------------------------------------------------- */
function initDashboard() {
  renderOverview();
  startCheckinDemo();

  // Wire sidebar
  document.querySelectorAll('.sb-item').forEach(b => {
    b.addEventListener('click', () => switchView(b.dataset.view));
  });
  // Links que mudam de view
  document.querySelectorAll('[data-view-go]').forEach(b => {
    b.addEventListener('click', () => switchView(b.dataset.viewGo));
  });

  // Search participantes
  const sp = document.getElementById('search-part');
  if (sp) {
    sp.addEventListener('input', e => renderParticipantes(e.target.value));
  }

  // Enter no manual code
  const mc = document.getElementById('manual-code');
  if (mc) {
    mc.addEventListener('keydown', e => {
      if (e.key === 'Enter') validateManual();
    });
  }
}

function init() {
  // Botão de login
  const btnLogin = document.getElementById('btnLogin');
  if (btnLogin) {
    btnLogin.addEventListener('click', login);
  }
  // Enter no campo de senha
  ['lg-email', 'lg-pass'].forEach(id => {
    const el = document.getElementById(id);
    if (el) el.addEventListener('keydown', e => { if (e.key === 'Enter') login(); });
  });

  // Auto-login se já autenticado
  if (checkAuth()) {
    showDashboard();
  }
}

document.addEventListener('DOMContentLoaded', init);
