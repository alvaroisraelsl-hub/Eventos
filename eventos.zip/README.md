# Alcance Eventos

Plataforma completa de venda de ingressos para a **Igreja Alcance** (Curitiba, PR).

Site público + dashboard de gestão. HTML, CSS e JS puros — sem build, sem dependências.

---

## 📁 Estrutura

```
alcance-eventos/
├── index.html       ← Site público
├── style.css        ← Design system (compartilhado)
├── script.js        ← Lógica do site público
├── gestao.html      ← Painel administrativo
├── gestao.css       ← Estilos do dashboard
├── gestao.js        ← Lógica do dashboard
└── README.md        ← Este arquivo
```

---

## 🚀 Como rodar

### Opção 1 — Abrir direto no navegador
Basta dar duplo-clique no `index.html`. Funciona offline em qualquer navegador moderno (Chrome, Firefox, Safari, Edge).

### Opção 2 — Servidor local (recomendado)
Para evitar limitações de CORS, rode um servidor local. Algumas alternativas rápidas:

```bash
# Python (já vem instalado em Mac/Linux)
cd alcance-eventos
python3 -m http.server 8000
# Abra http://localhost:8000

# Node.js
npx serve

# PHP
php -S localhost:8000
```

### Opção 3 — Hospedar online (grátis)
- **Vercel:** arraste a pasta em [vercel.com](https://vercel.com) → site no ar em 30s
- **Netlify:** arraste em [app.netlify.com/drop](https://app.netlify.com/drop)
- **GitHub Pages:** suba os arquivos num repositório e ative Pages

---

## 🎨 Funcionalidades

### Site público (`index.html`)
- **Intro animada** estilo trailer ("Alcance" → "Eventos" → site aparece)
- **Carrossel 3D** com cards empilhados, navegação por:
  - Setas pulsantes douradas
  - Arrastar com mouse / swipe no celular
  - Setas do teclado (← →)
  - Pontos indicadores
  - Auto-rotação a cada 7 segundos (pausa em hover)
- **Modal de evento** com 3 visões em fluxo único:
  1. Detalhe + escolha de ingressos com contadores
  2. Checkout com dados pessoais e forma de pagamento (Pix/Cartão)
  3. Confirmação com ingresso digital + QR Code
- **Persistência local:** cada reserva é salva no `localStorage` e aparece no dashboard

### Dashboard de gestão (`gestao.html`)
Botão "Gestão" pequeno no topo direito do site.

**Login demo:** qualquer e-mail e senha funcionam (já vêm pré-preenchidos).

Views do painel:
- **Visão Geral:** 4 métricas, ranking de vendas por evento, atividade em tempo real, gráfico de vendas dos últimos 30 dias
- **Eventos:** tabela com vendas, receita e status de cada evento
- **Participantes:** lista completa com busca, mistura dados mock + reservas reais feitas no site
- **Check-in:** scanner visual animado + validação manual por código (use os IDs `CF-1234-ABCD` etc. para testar)
- **Financeiro:** receita bruta/líquida, breakdown Pix vs Cartão, transações
- **Relatórios:** 4 tipos de relatório (mock — pronto para integração)
- **Configurações:** dados da igreja, conta bancária, equipe

---

## 🧪 Como testar o fluxo completo

1. Abra `index.html`
2. Aguarde a intro (pula automaticamente após 3s)
3. Clique em **"Reservar"** num card
4. Escolha quantidade de ingressos
5. Continue para checkout, preencha qualquer dado, escolha Pix
6. Confirme — você verá o ingresso digital com QR Code
7. **Abra `gestao.html`** em outra aba
8. Faça login (qualquer credencial)
9. Vá para **Participantes** — a reserva que você acabou de fazer aparece lá!
10. Vá para **Check-in** e cole o código do ingresso para validar a entrada

---

## 🎨 Design System

**Tipografia:**
- Cormorant Garamond (serif) — títulos, valores, números
- Outfit (sans) — corpo, UI, labels

**Paleta — psicologia do luxo:**
- Dourado principal: `#C9A84C`
- Dourado claro: `#E8CC7A`
- Dourado escuro: `#8A6A1E`
- Fundo dark warm: `#0E0B07` · `#17120C` · `#1F1810`
- Cream: `#FDFAF3`

Todas as cores são variáveis CSS — basta editar o `:root` no `style.css` para mudar a identidade visual.

---

## 🔌 Próximos passos (para produção)

Esse projeto é um **MVP visual completo e funcional** — perfeito para validação, demonstração e como base para integração com backend real. Para colocar em produção com pagamentos reais:

1. **Backend:** criar API REST (Node/Express, Django, etc.) substituindo o `localStorage`
2. **Pagamento real:** integrar **Pagar.me**, **Mercado Pago** ou **Stripe** (Pix e Cartão)
3. **E-mail transacional:** **SendGrid**, **Mailgun** ou **Resend** para enviar ingressos
4. **QR Code real:** usar `qrcode.js` ou `qrcode-generator` (o atual é visual decorativo)
5. **Autenticação real:** **Auth0**, **Firebase Auth** ou auth próprio com JWT
6. **Banco de dados:** PostgreSQL, MongoDB, ou Firebase
7. **Scanner real de câmera:** `html5-qrcode` para leitura de QR via webcam/celular

---

## ✨ Detalhes de polimento

- Suporte completo a teclado e leitores de tela onde possível
- Animações com `cubic-bezier` customizado para suavidade premium
- Responsivo de 320px (mobile) até 4K (desktop)
- Setas com dois rings pulsantes assíncronos (efeito luminoso)
- Cards do carrossel com perspectiva 3D real (rotateY + scale + opacity)
- Inputs com máscaras automáticas (CPF, telefone)
- Toast notifications elegantes
- Cores selection customizadas (douradas)
- Scrollbar customizada

---

**Igreja Alcance** · Curitiba, PR · 2025
