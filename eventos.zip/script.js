/* ====================================================================
   ALCANCE EVENTOS — Script Principal
   - Intro animation
   - Carousel stack 3D
   - Modal de evento + checkout + sucesso
   - Geração de QR code (visual)
   - Persistência de reservas em localStorage para integração com gestão
   ==================================================================== */

/* ---------------------------------------------------
   DADOS DOS EVENTOS
--------------------------------------------------- */
const EVENTOS = [
  {
    id: 'conf-fe-2025',
    bg: 'bg-1',
    name: 'Conferência da Fé 2025',
    date: '22 de Junho · Domingo',
    dateShort: '22 Jun · Domingo · 19h',
    time: '19:00',
    duration: '3 horas',
    spots: '500 vagas',
    local: 'Templo Central · Curitiba, PR',
    address: 'Rua das Flores, 1500 · Curitiba',
    badge: 'Em destaque',
    badgeClass: '',
    desc: 'Três dias de pregação, louvor e renovação espiritual com convidados especiais. Uma conferência transformadora para fortalecer sua fé e comunhão com Deus.',
    priceFrom: 79,
    types: [
      { id: 't1', name: 'Acesso Geral', desc: 'Área principal · Acomodação confortável', price: 79 },
      { id: 't2', name: 'Área VIP', desc: 'Primeiras fileiras + kit conferência', price: 149 },
      { id: 't3', name: 'Família (2+2)', desc: '2 adultos e 2 crianças até 12 anos', price: 249 }
    ]
  },
  {
    id: 'retiro-verao',
    bg: 'bg-2',
    name: 'Retiro de Verão',
    date: '12 a 14 de Julho',
    dateShort: '12–14 Jul · Fim de semana',
    time: 'A partir das 18h',
    duration: '3 dias',
    spots: '200 vagas',
    local: 'Sítio Renova · Piraquara, PR',
    address: 'Estrada da Graciosa, km 22 · Piraquara',
    badge: 'Poucas vagas',
    badgeClass: '',
    desc: 'Fim de semana imersivo em meio à natureza. Hospedagem, alimentação completa, dinâmicas em grupo, momentos de adoração e tempo para descanso e oração.',
    priceFrom: 149,
    types: [
      { id: 't1', name: 'Individual', desc: 'Hospedagem + alimentação completa', price: 189 },
      { id: 't2', name: 'Casal', desc: 'Acomodação dupla com pensão completa', price: 340 },
      { id: 't3', name: 'Estudante', desc: 'Com comprovante de matrícula', price: 149 }
    ]
  },
  {
    id: 'noite-louvor',
    bg: 'bg-3',
    name: 'Noite de Louvor',
    date: '5 de Agosto · Terça-feira',
    dateShort: '5 Ago · Terça · 20h',
    time: '20:00',
    duration: '2 horas',
    spots: '800 lugares',
    local: 'Auditório Central · Curitiba, PR',
    address: 'Av. Cândido de Abreu, 200 · Curitiba',
    badge: 'Gratuito',
    badgeClass: 'muted',
    desc: 'Uma noite especial dedicada inteiramente ao louvor. Banda da igreja com participações especiais. Entrada gratuita, contribuição voluntária para a obra.',
    priceFrom: 0,
    types: [
      { id: 't1', name: 'Acesso Livre', desc: 'Entrada gratuita · Reserva obrigatória', price: 0 },
      { id: 't2', name: 'Apoiador', desc: 'Contribuição voluntária para a obra', price: 30 }
    ]
  },
  {
    id: 'noite-nacoes',
    bg: 'bg-4',
    name: 'Noite das Nações',
    date: '14 de Setembro · Sábado',
    dateShort: '14 Set · Sábado · 18h',
    time: '18:00',
    duration: '4 horas',
    spots: '600 lugares',
    local: 'Sede Central · Curitiba, PR',
    address: 'Rua das Flores, 1500 · Curitiba',
    badge: 'Novo',
    badgeClass: '',
    desc: 'Uma noite celebrando a missão global da igreja. Apresentações culturais, palestras com missionários e jantar inspirado em pratos típicos das nações alcançadas.',
    priceFrom: 0,
    types: [
      { id: 't1', name: 'Entrada Gratuita', desc: 'Reserva obrigatória', price: 0 },
      { id: 't2', name: 'Jantar Internacional', desc: 'Acesso ao evento + jantar completo', price: 89 }
    ]
  },
  {
    id: 'casais-conexao',
    bg: 'bg-5',
    name: 'Casais em Conexão',
    date: '11 de Outubro · Sábado',
    dateShort: '11 Out · Sábado · 19h',
    time: '19:00',
    duration: '4 horas',
    spots: '120 casais',
    local: 'Salão Nobre · Curitiba, PR',
    address: 'Rua das Flores, 1500 · Curitiba',
    badge: 'Reservas abertas',
    badgeClass: 'muted',
    desc: 'Encontro romântico e profundo para casais. Jantar à luz de velas, mensagem inspiradora sobre amor cristão e momentos a dois. Uma noite para reacender o relacionamento.',
    priceFrom: 220,
    types: [
      { id: 't1', name: 'Casal Padrão', desc: 'Jantar completo · Mesa compartilhada', price: 220 },
      { id: 't2', name: 'Casal Premium', desc: 'Mesa exclusiva + brinde personalizado', price: 360 }
    ]
  },
  {
    id: 'celebracao-natal',
    bg: 'bg-6',
    name: 'Celebração de Natal',
    date: '20 de Dezembro · Sábado',
    dateShort: '20 Dez · Sábado · 19h',
    time: '19:00',
    duration: '2h30',
    spots: '1000 lugares',
    local: 'Templo Central · Curitiba, PR',
    address: 'Rua das Flores, 1500 · Curitiba',
    badge: 'Tradicional',
    badgeClass: 'muted',
    desc: 'A tradicional celebração natalina da Alcance. Cantata especial, encenação do nascimento de Cristo, ceia simbólica e mensagem de Natal. Para toda a família.',
    priceFrom: 0,
    types: [
      { id: 't1', name: 'Entrada Geral', desc: 'Reserva obrigatória', price: 0 },
      { id: 't2', name: 'Família', desc: 'Mesa para 4 pessoas + kit natalino', price: 120 }
    ]
  }
];

/* ---------------------------------------------------
   INTRO ANIMATION
--------------------------------------------------- */
function runIntro() {
  const intro = document.getElementById('intro');
  const site = document.getElementById('site');

  // Não rodar se já viu nessa sessão
  if (sessionStorage.getItem('introSeen') === '1') {
    intro.style.display = 'none';
    site.classList.add('visible');
    return;
  }

  setTimeout(() => intro.classList.add('show-glow'), 100);
  setTimeout(() => intro.classList.add('show-alcance'), 400);
  setTimeout(() => intro.classList.add('show-eventos'), 1200);
  setTimeout(() => intro.classList.add('show-line'), 1600);
  setTimeout(() => {
    intro.classList.add('fade-out');
    site.classList.add('visible');
  }, 3000);
  setTimeout(() => {
    intro.style.display = 'none';
    sessionStorage.setItem('introSeen', '1');
  }, 4000);
}

/* ---------------------------------------------------
   RENDER DOS CARDS DE EVENTO
--------------------------------------------------- */
function renderCards() {
  const stack = document.getElementById('stack');
  stack.innerHTML = '';

  EVENTOS.forEach((ev, idx) => {
    const card = document.createElement('div');
    card.className = 'event-card';
    card.dataset.idx = idx;

    const priceHtml = ev.priceFrom === 0
      ? `<div class="event-card-free">Gratuito</div>`
      : `<div class="event-card-price">R$ ${ev.priceFrom} <span>/ a partir</span></div>`;

    card.innerHTML = `
      <div class="event-card-img ${ev.bg}">
        <div class="event-card-symbol">✦</div>
        ${ev.badge ? `<div class="event-card-badge ${ev.badgeClass}">${ev.badge}</div>` : ''}
      </div>
      <div class="event-card-body">
        <div class="event-card-date">${ev.dateShort}</div>
        <div class="event-card-name">${ev.name}</div>
        <div class="event-card-local">${ev.local}</div>
        <div class="event-card-footer">
          ${priceHtml}
          <button class="btn btn-gold btn-sm" data-action="reserve" data-idx="${idx}">Reservar</button>
        </div>
      </div>
    `;
    stack.appendChild(card);
  });

  // Render dos dots
  const dotsEl = document.getElementById('dots');
  dotsEl.innerHTML = '';
  EVENTOS.forEach((_, i) => {
    const d = document.createElement('button');
    d.className = 'dot' + (i === 0 ? ' active' : '');
    d.setAttribute('aria-label', `Ir para evento ${i + 1}`);
    d.addEventListener('click', () => goTo(i));
    dotsEl.appendChild(d);
  });

  // Wire up botões "Reservar"
  stack.querySelectorAll('[data-action="reserve"]').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      openModal(parseInt(btn.dataset.idx));
    });
  });
}

/* ---------------------------------------------------
   CAROUSEL STACK 3D
--------------------------------------------------- */
let current = 0;
const N = () => EVENTOS.length;

function applyPositions() {
  const cards = document.querySelectorAll('.event-card');
  cards.forEach(card => {
    const idx = parseInt(card.dataset.idx);
    const rel = (idx - current + N()) % N();
    // Remove todas as classes pos-*
    card.className = card.className.replace(/\bpos-\S+/g, '').trim();
    if (rel === 0) card.classList.add('pos-0');
    else if (rel === 1) card.classList.add('pos-1');
    else if (rel === 2) card.classList.add('pos-2');
    else if (rel === 3) card.classList.add('pos-3');
    else if (rel === 4) card.classList.add('pos-4');
    else card.classList.add('pos-far');
  });
  updateDots();
}

function updateDots() {
  document.querySelectorAll('.dot').forEach((d, i) => {
    d.classList.toggle('active', i === current);
  });
}

function goNext() {
  current = (current + 1) % N();
  applyPositions();
}
function goPrev() {
  current = (current - 1 + N()) % N();
  applyPositions();
}
function goTo(i) {
  current = i;
  applyPositions();
}

/* ---------------------------------------------------
   SWIPE / DRAG NO STACK
--------------------------------------------------- */
function setupDrag() {
  const stack = document.getElementById('stack');
  let startX = null;
  let moved = false;

  const start = (x) => { startX = x; moved = false; };
  const move = (x) => {
    if (startX !== null && Math.abs(x - startX) > 8) moved = true;
  };
  const end = (x) => {
    if (startX === null) return;
    const dx = x - startX;
    if (Math.abs(dx) > 60) {
      dx < 0 ? goNext() : goPrev();
    }
    startX = null;
  };

  stack.addEventListener('mousedown', e => start(e.clientX));
  stack.addEventListener('mousemove', e => move(e.clientX));
  stack.addEventListener('mouseup', e => end(e.clientX));
  stack.addEventListener('mouseleave', () => { startX = null; });

  stack.addEventListener('touchstart', e => start(e.touches[0].clientX), { passive: true });
  stack.addEventListener('touchmove', e => move(e.touches[0].clientX), { passive: true });
  stack.addEventListener('touchend', e => end(e.changedTouches[0].clientX));

  // Click no card (não foi drag) → avança ou abre
  stack.addEventListener('click', e => {
    if (moved) return;
    const card = e.target.closest('.event-card');
    if (!card) return;
    if (e.target.closest('[data-action="reserve"]')) return;
    const idx = parseInt(card.dataset.idx);
    const rel = (idx - current + N()) % N();
    if (rel === 0) {
      openModal(idx);
    } else {
      goTo(idx);
    }
  });
}

/* ---------------------------------------------------
   MODAL — DETALHE + CHECKOUT + SUCESSO
--------------------------------------------------- */
let currentEv = null;
let qtys = {};
let currentPayment = 'pix';

function openModal(idx) {
  currentEv = EVENTOS[idx];
  qtys = {};
  currentEv.types.forEach(t => { qtys[t.id] = 0; });

  // View detalhe
  showView('view-detail');
  const m = currentEv;
  document.getElementById('modalImg').className = 'modal-img ' + m.bg;
  document.getElementById('m-eyebrow').textContent = m.dateShort;
  document.getElementById('m-title').textContent = m.name;
  document.getElementById('m-local').textContent = m.local;
  document.getElementById('m-date').textContent = m.date.split(' · ')[0];
  document.getElementById('m-time').textContent = m.time;
  document.getElementById('m-duration').textContent = m.duration;
  document.getElementById('m-spots').textContent = m.spots;
  document.getElementById('m-desc').textContent = m.desc;

  // Render tipos
  const list = document.getElementById('m-types');
  list.innerHTML = '';
  m.types.forEach(t => {
    const row = document.createElement('div');
    row.className = 'ttype-row';
    row.dataset.id = t.id;
    row.innerHTML = `
      <div class="ttype-info">
        <div class="ttype-name">${t.name}</div>
        <div class="ttype-desc">${t.desc}</div>
      </div>
      <div class="ttype-right">
        <div class="ttype-price ${t.price === 0 ? 'free' : ''}">${t.price === 0 ? 'Grátis' : 'R$ ' + t.price}</div>
        <div class="qty-wrap">
          <button class="qb" data-act="minus" data-id="${t.id}" aria-label="Diminuir">−</button>
          <span class="qn" id="qn-${t.id}">0</span>
          <button class="qb" data-act="plus" data-id="${t.id}" aria-label="Aumentar">+</button>
        </div>
      </div>
    `;
    list.appendChild(row);
  });

  // Wire qty
  list.querySelectorAll('.qb').forEach(b => {
    b.addEventListener('click', e => {
      const id = b.dataset.id;
      const d = b.dataset.act === 'plus' ? 1 : -1;
      qtys[id] = Math.max(0, qtys[id] + d);
      document.getElementById('qn-' + id).textContent = qtys[id];
      const row = list.querySelector(`[data-id="${id}"]`);
      if (row) row.classList.toggle('selected', qtys[id] > 0);
      updateTotal();
    });
  });

  updateTotal();

  // Abre modal
  document.getElementById('modal').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function updateTotal() {
  let total = 0;
  currentEv.types.forEach(t => { total += (qtys[t.id] || 0) * t.price; });
  const el = document.getElementById('m-total');
  el.textContent = total === 0 ? 'R$ 0' : 'R$ ' + total.toLocaleString('pt-BR');

  const hasAny = Object.values(qtys).some(q => q > 0);
  document.getElementById('btnCheckout').disabled = !hasAny;
}

function closeModal() {
  document.getElementById('modal').classList.remove('open');
  document.body.style.overflow = '';
}

function showView(viewId) {
  ['view-detail', 'view-checkout', 'view-success'].forEach(id => {
    const el = document.getElementById(id);
    if (id === viewId) {
      el.style.display = '';
      if (id === 'view-checkout' || id === 'view-success') el.classList.add('active');
    } else {
      el.style.display = 'none';
      el.classList.remove('active');
    }
  });
  document.getElementById('modalInner').scrollTop = 0;
}

function backToDetail() {
  showView('view-detail');
}

function goToCheckout() {
  // Monta resumo
  document.getElementById('c-title').textContent = currentEv.name;
  const summary = document.getElementById('c-summary');
  summary.innerHTML = '';
  let total = 0;
  currentEv.types.forEach(t => {
    const q = qtys[t.id] || 0;
    if (q > 0) {
      const sub = q * t.price;
      total += sub;
      const row = document.createElement('div');
      row.className = 'checkout-sum-row';
      row.innerHTML = `<span>${q}× ${t.name}</span><span>${t.price === 0 ? 'Grátis' : 'R$ ' + sub.toLocaleString('pt-BR')}</span>`;
      summary.appendChild(row);
    }
  });
  const totRow = document.createElement('div');
  totRow.className = 'checkout-sum-row total';
  totRow.innerHTML = `<span>Total</span><span>${total === 0 ? 'R$ 0' : 'R$ ' + total.toLocaleString('pt-BR')}</span>`;
  summary.appendChild(totRow);

  showView('view-checkout');
}

function goToSuccess() {
  const nome = document.getElementById('cf-nome').value.trim() || 'Convidado';
  const email = document.getElementById('cf-email').value.trim();

  // Validação simples
  if (!nome || !email) {
    showToast('Preencha nome e e-mail');
    return;
  }

  // Pega o primeiro tipo com qty > 0 (para exibir no ingresso digital)
  const tipoSelecionado = currentEv.types.find(t => (qtys[t.id] || 0) > 0);
  const codigo = generateCode(currentEv.id);

  // Persistência: salva no localStorage para a gestão ler
  const reserva = {
    id: codigo,
    eventId: currentEv.id,
    eventName: currentEv.name,
    eventDate: currentEv.dateShort,
    local: currentEv.local,
    portador: nome,
    email,
    cpf: document.getElementById('cf-cpf').value.trim(),
    telefone: document.getElementById('cf-tel').value.trim(),
    tipo: tipoSelecionado ? tipoSelecionado.name : '—',
    quantidades: Object.fromEntries(Object.entries(qtys).filter(([_, q]) => q > 0)),
    pagamento: currentPayment,
    total: Object.entries(qtys).reduce((acc, [id, q]) => {
      const t = currentEv.types.find(x => x.id === id);
      return acc + (q * (t ? t.price : 0));
    }, 0),
    timestamp: Date.now(),
    status: 'pago',
    validated: false
  };

  // Lê reservas anteriores e adiciona
  const all = JSON.parse(localStorage.getItem('alcance_reservas') || '[]');
  all.push(reserva);
  localStorage.setItem('alcance_reservas', JSON.stringify(all));

  // Preenche tela de sucesso
  document.getElementById('dt-event').textContent = currentEv.name;
  document.getElementById('dt-date').textContent = currentEv.date + ' · ' + currentEv.time;
  document.getElementById('dt-portador').textContent = nome;
  document.getElementById('dt-tipo').textContent = reserva.tipo;
  document.getElementById('dt-local').textContent = currentEv.local.split(' · ')[0];
  document.getElementById('dt-code').textContent = '#' + codigo;
  document.getElementById('dt-qr-id').textContent = codigo;
  renderQR(codigo);

  showView('view-success');
}

function generateCode(eventId) {
  const prefix = eventId.split('-').map(s => s[0]).join('').toUpperCase();
  const rand = Math.random().toString(36).substring(2, 6).toUpperCase();
  const num = Math.floor(Math.random() * 9000 + 1000);
  return `${prefix}-${num}-${rand}`;
}

function renderQR(code) {
  // QR visual: grid de "células" baseado em hash do código
  // (em produção, gerar QR real com biblioteca como qrcode.js)
  const box = document.getElementById('dt-qr');
  box.innerHTML = '';
  const size = 7;
  const grid = document.createElement('div');
  grid.style.cssText = `display:grid;grid-template-columns:repeat(${size},1fr);gap:1px;width:64px;height:64px;`;

  // Gera um padrão pseudo-aleatório baseado no código
  let seed = 0;
  for (let i = 0; i < code.length; i++) seed = (seed * 31 + code.charCodeAt(i)) & 0xffffffff;
  function next() { seed = (seed * 1103515245 + 12345) & 0x7fffffff; return seed; }

  for (let i = 0; i < size * size; i++) {
    const cell = document.createElement('div');
    // Cantos sempre cheios (estilo QR)
    const row = Math.floor(i / size), col = i % size;
    const corner =
      (row < 2 && col < 2) ||
      (row < 2 && col >= size - 2) ||
      (row >= size - 2 && col < 2);
    const filled = corner || (next() % 2 === 0);
    cell.style.background = filled ? '#1A1612' : 'transparent';
    cell.style.borderRadius = '0.5px';
    grid.appendChild(cell);
  }
  box.appendChild(grid);
}

/* ---------------------------------------------------
   FORMATAÇÕES DE INPUT
--------------------------------------------------- */
function setupInputMasks() {
  const cpf = document.getElementById('cf-cpf');
  if (cpf) {
    cpf.addEventListener('input', e => {
      let v = e.target.value.replace(/\D/g, '').slice(0, 11);
      v = v.replace(/(\d{3})(\d)/, '$1.$2');
      v = v.replace(/(\d{3})(\d)/, '$1.$2');
      v = v.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
      e.target.value = v;
    });
  }
  const tel = document.getElementById('cf-tel');
  if (tel) {
    tel.addEventListener('input', e => {
      let v = e.target.value.replace(/\D/g, '').slice(0, 11);
      if (v.length > 6) v = v.replace(/(\d{2})(\d{5})(\d{0,4})/, '($1) $2-$3');
      else if (v.length > 2) v = v.replace(/(\d{2})(\d{0,5})/, '($1) $2');
      e.target.value = v;
    });
  }
}

/* ---------------------------------------------------
   TOAST
--------------------------------------------------- */
function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  setTimeout(() => t.classList.remove('show'), 2400);
}

/* ---------------------------------------------------
   SETUP GERAL
--------------------------------------------------- */
function init() {
  runIntro();
  renderCards();
  applyPositions();
  setupDrag();
  setupInputMasks();

  // Arrows
  document.getElementById('btnNext').addEventListener('click', goNext);
  document.getElementById('btnPrev').addEventListener('click', goPrev);

  // Auto-rotate (a cada 7s, pausa em hover)
  let auto = setInterval(goNext, 7000);
  const stack = document.getElementById('stack');
  stack.addEventListener('mouseenter', () => clearInterval(auto));
  stack.addEventListener('mouseleave', () => { auto = setInterval(goNext, 7000); });

  // Keyboard
  document.addEventListener('keydown', e => {
    if (document.getElementById('modal').classList.contains('open')) {
      if (e.key === 'Escape') closeModal();
      return;
    }
    if (e.key === 'ArrowRight') goNext();
    if (e.key === 'ArrowLeft') goPrev();
  });

  // Checkout
  document.getElementById('btnCheckout').addEventListener('click', goToCheckout);
  document.getElementById('btnPay').addEventListener('click', goToSuccess);

  // Payment options
  document.querySelectorAll('.pay-option').forEach(opt => {
    opt.addEventListener('click', () => {
      document.querySelectorAll('.pay-option').forEach(o => o.classList.remove('selected'));
      opt.classList.add('selected');
      currentPayment = opt.dataset.pay;
    });
  });

  // Click fora do modal
  document.getElementById('modal').addEventListener('click', e => {
    if (e.target.id === 'modal') closeModal();
  });
}

document.addEventListener('DOMContentLoaded', init);
